package es.ies.puerto.fichero.examen;

import java.io.File;

public class Ejercicio2 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

    public static boolean existeDirectorio(String nombreDirectorio) {
        return true;
    }
}