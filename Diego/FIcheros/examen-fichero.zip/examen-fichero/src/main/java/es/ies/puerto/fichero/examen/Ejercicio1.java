package es.ies.puerto.fichero.examen;

import java.io.File;

public class Ejercicio1 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

    public static boolean existeFichero(String nombreFichero) {
        return true;
    }
}