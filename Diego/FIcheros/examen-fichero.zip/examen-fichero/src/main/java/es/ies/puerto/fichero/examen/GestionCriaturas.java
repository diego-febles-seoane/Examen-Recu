package es.ies.puerto.fichero.examen;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import es.ies.puerto.Criatura;

public class GestionCriaturas {

    private List<Criatura> listaCriaturas;
    private final String FICHERO = "";

    

    public boolean insertar(Criatura criatura) {
        return false;
    }

    public boolean borrar(String id) {
        return false;
    }

    public List<Criatura> obtenerCriaturas() {
        return null;
    }

    public void modificar(Criatura nuevaModificada) {
        
    }

    public Criatura buscar(String id) {
        return null;  
    }

    public List<Criatura> buscarPorNombre(String nombre) {
        return null;
    }

    public List<Criatura> buscarPorOrigen(String origen) {
        return null;
    }
}
