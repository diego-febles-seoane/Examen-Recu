# Trabajo con Ficheros (Comandos a utilizar)

```cmd
cd src/main/resources
pwd
```

__captura el valor y se lo añades en path.__