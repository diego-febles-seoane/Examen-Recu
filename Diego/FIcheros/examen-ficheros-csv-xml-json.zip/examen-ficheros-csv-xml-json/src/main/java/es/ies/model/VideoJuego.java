package es.ies.model;


public class VideoJuego {

    private int id;
    private String nombre;
    private String plataforma;
    private String fechaLanzamiento;

    public VideoJuego() {
    }

    public VideoJuego(int id) {

    }

    public VideoJuego(int id, String nombre, String plataforma, String fechaLanzamiento) {
        
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPlataforma() {
        return plataforma;
    }

    public String getFechaLanzamiento() {
        return fechaLanzamiento;
    }

    


    

    
    

}
